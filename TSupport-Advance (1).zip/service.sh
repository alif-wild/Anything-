# Define Variable & Directory
MAGISK_VER="$(magisk -V)"
SHAMIKO="/data/adb/modules/zygisk_shamiko"
TARGET_DIR="/data/adb/tricky_store"
TARGET_FILE="$TARGET_DIR/target.txt"
TARGET_BACKUP="$TARGET_DIR/target.txt.bak"
EXCLUDE_FILE="/sdcard/exclude.txt"
AUTOLOG="$TARGET_DIR/autolog"

# Delete old action
[ -f $SHAMIKO/action.sh ] && rm -rf $SHAMIKO/action.sh

# Sleep for a second until /sdcard mount
while [ ! -d /sdcard ] || [ ! "$(ls -A /sdcard)" ]; do
    sleep 2
done

# Condition Checker
if [ "$MAGISK_VER" -gt 27007 ]; then
    echo """#!/bin/sh
DIR=\"/data/adb/shamiko\"
    
if [ -d \$DIR ] && [ -f \$DIR/whitelist ]; then
    rm -rf \$DIR/whitelist
    sleep 0.4
    exit 0
elif [ -d \$DIR ] && [ ! -f \$DIR/whitelist ]; then
    touch \$DIR/whitelist
    sleep 0.4
    exit 0
else
    echo -e \"! ERROR : Shamiko directory not found\"
    exit 1
fi
""" > $SHAMIKO/action.sh
fi

backup_target() {
    [ -f "$TARGET_FILE" ] && [ ! -f "$TARGET_BACKUP" ] && cat "$TARGET_FILE" > "$TARGET_BACKUP" # && echo "backup done" >> /sdcard/tsplog # Dbug
}

update_autolog() {
    # Get the list of package names
    if [ -d "$TARGET_DIR" ]; then
     
        # Get all installed package names
        packages=$(awk '{print $1}' /data/system/packages.list)
            
        # Loop through each package
        for package in $packages; do
            if [ -f /sdcard/customize.txt ]; then
                # Check if package is forced with GCS mode (!), LHM mode (?), or excluded
                if grep -q "^$package!$" /sdcard/customize.txt; then
                    echo "$package!" >> "$AUTOLOG" # && echo "$package!" >> /sdcard/tsplog # Dbug
                    continue
        
                elif grep -q "teeBroken=false" "$TARGET_DIR/tee_status" && grep -q "^$package?$" /sdcard/customize.txt; then
                    echo "$package?" >> "$AUTOLOG" # && echo "$package?" >> /sdcard/tsplog # Dbug
                    continue
        
                elif grep -q "^$package$" /sdcard/customize.txt; then
                    # echo "$package exclude" >> /sdcard/tsplog # Dbug
                    sleep 0.5
                    continue
                fi
        
                # If the first line is "!", force GCS mode for all remaining packages
                if head -n 1 /sdcard/customize.txt | grep -q "^!$"; then
                    echo "$package!" >> "$AUTOLOG" # && echo "all package with !" >> /sdcard/tsplog # Dbug
                    
                else
                    echo "$package" >> "$AUTOLOG" # && echo "Package added normally" >> /sdcard/tsplog # Dbug  # Default Auto Mode
                fi
            else
                # If no customize.txt, use Auto Mode
                echo "$package" >> "$AUTOLOG" # && echo "No customize fiel" >> /sdcard/tsplog # Dbug
            fi
        done
    else
        # If customize.txt does not exist, add all packages in Auto Mode
        for package in $packages; do
            echo "$package" >> "$AUTOLOG" # && echo "No $TARGET_DIR" >> /sdcard/tsplog # Dbug
        done
    fi
    
    # Save results from AUTOLOG to TARGET_FILE and delete AUTOLOG
    [ -f "$AUTOLOG" ] && cat "$AUTOLOG" > "$TARGET_FILE" && rm -f "$AUTOLOG" # && echo "Completed" >> /sdcard/tsplog # Dbug
}

# First Init
# backup_target
# update_autolog

# Looping Services
while true; do
    # Auto Target Service
    if [ -f /sdcard/stop-tspa-auto-target ]; then
        backup_target
        update_autolog
        break
        
    elif [ -d "$TARGET_DIR" ]; then
        backup_target
        update_autolog
        sleep 60
        continue
    fi
done &

if [ -n "$(resetprop ro.build.selinux)" ]; then
    resetprop --delete ro.build.selinux
fi

killall -v com.google.android.gms
killall -v com.google.android.gms.unstable