# Set directory variable
SHAMIKO="/data/adb/modules/zygisk_shamiko"
TARGET_DIR="/data/adb/tricky_store"
TARGET_FILE="$TARGET_DIR/target.txt"
TARGET_BACKUP="$TARGET_DIR/target.txt.bak"
ROM_SIGN_PATH="/system/etc/security"

# Extract the version from the module.prop file
VERNAME=$(grep 'version=' $MODPATH/module.prop | cut -d '=' -f 2)
VERCODE=$(grep 'versionCode=' $MODPATH/module.prop | cut -d '=' -f 2)
OLDVERCODE=$(grep 'versionCode=' /data/adb/modules/tsupport-advance/module.prop | cut -d '=' -f 2)

if [ $OLDVERCODE -lt $VERCODE ]; then
    touch /data/adb/modules/tsupport-advance/update
    cat $MODPATH/module.prop > /data/adb/modules/tsupport-advance/module.prop
fi

# Function to check Internet connectivity
check_internet() {
    # Try to connect to 8.8.8.8 with a 3-second timeout
    if ! timeout 3 ping -c 1 8.8.8.8 > /dev/null 2>&1; then
        # If ping to 8.8.8.8 fails, try google.com
        if ! timeout 3 ping -c 1 google.com > /dev/null 2>&1; then
            # Abort if both checks fail
            abort "! Unable to connect to Internet"
        fi
    fi
}

if [ "$BOOTMODE" ] && [ "$KSU" ]; then
    echo "- Installation with KernelSU"
    # Define a function to run commands with root privileges using Magisk
    cmd() { /data/adb/ksu/bin/busybox "$@"; }
    
elif [ "$BOOTMODE" ] && [ "$APATCH" ]; then
    echo "- Installation with Apatch"
    # Define a function to run commands with root privileges using Magisk
    cmd() { /data/adb/ap/bin/busybox "$@"; }
    
elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
    echo "- Installation with Magisk $MAGISK_VER($MAGISK_VER_CODE)"
    # Define a function to run commands with root privileges using Magisk
    [ $MAGISK_VER_CODE -lt 27008 ] && cmd() { su -c "$@"; } || cmd() { /data/adb/magisk/magisk su -c "$@"; }
    shamiko() {
    echo """#!/bin/sh
DIR=\"/data/adb/shamiko\"
    
if [ -d \$DIR ] && [ -f \$DIR/whitelist ]; then
    rm -rf \$DIR/whitelist
    sleep 0.4
    exit 0
elif [ -d \$DIR ] && [ ! -f \$DIR/whitelist ]; then
    touch \$DIR/whitelist
    sleep 0.4
    exit 0
else
    echo -e \"! ERROR : Shamiko directory not found\"
    exit 1
fi
""" > $SHAMIKO/action.sh
    [ -d $SHAMIKO ] && shamiko
}

else
    # Print Abort Message
    abort "! Installation from recovery not supported"
fi

# Display the text with the extracted version
echo -e "\nTSupport-Advance-$VERNAME($VERCODE)"
sleep 0.8  # Delay for 0.8 seconds
echo "Open Source Project ( OSP )"
sleep 0.8  # Delay for 0.8 seconds
echo -e "Brought by Citra-Standalone\n"
sleep 0.5

# Indicator
echo "============================"

# ROM Sign Check
if unzip -l $ROM_SIGN_PATH/otacerts.zip | grep -q "testkey" ; then
    echo -e "ROM Sign : testkey"
elif unzip -l $ROM_SIGN_PATH/otacerts.zip | grep -q "releasekey" ; then
    echo -e "ROM Sign : releasekey"
else
    echo -e "ROM Sign : unknown"
fi

# TEE Detection
if [ -d "$TARGET_DIR" ] && grep -q "teeBroken=true" "$TARGET_DIR/tee_status"; then
    echo -e "TEE Status : broken"
elif [ -d "$TARGET_DIR" ] && grep -q "teeBroken=false" "$TARGET_DIR/tee_status"; then
    echo -e "TEE Status : normal"
else
    echo -e "TEE Status : unknown"
fi

# XiaomiEU Disable Inject Module
if cat /data/system/packages.list | awk '{print $1}' | grep eu.xiaomi.module.inject >> /dev/null || getprop ro.product.mod_device | grep xiaomieu; then
    echo "XEU ROM : true"
    su -c pm disable eu.xiaomi.module.inject >> /dev/null
else
    echo "XEU ROM : false"
fi

# Auto Target Detection
if [ -f /sdcard/stop-tspa-auto-target ]; then
    echo "Auto Target : Offline"
elif [ ! -f /sdcard/stop-tspa-auto-target ]; then
    echo "Auto Target : Online"
else
    echo "Auto Target : Unknown"
fi

# Close Indicator
echo "============================"

# Call the Internet check function
check_internet

# Check if the Tricky Store directory exists
if [ -d "$TARGET_DIR" ]; then
    # Check if target.txt exists
    if [ -f "$TARGET_FILE" ]; then
        # If a backup of target.txt exists, remove target.txt
        if [ -f "$TARGET_BACKUP" ]; then
            su -c rm -rf "$TARGET_FILE"
        else
            # Otherwise, back up target.txt
            su -c mv "$TARGET_FILE" "$TARGET_BACKUP" && ui_print "> Backup done🥰"
        fi
    fi

    # Get all installed package names
    packages=$(awk '{print $1}' /data/system/packages.list)

    # CITarget Indicator
    if head -n 1 /sdcard/customize.txt | grep -q "^!$"; then
        echo -e "\n=== CITarget-GCS-MODE ==="
    else
        echo -e "\n=== CITarget-AUTO-MODE ==="
    fi
    [ -f /sdcard/customize.txt ] && echo "> customize.txt found"
    
    # Loop through each package
    for package in $packages; do
        if [ -f /sdcard/customize.txt ]; then
            # Check if package is forced with GCS mode (!), LHM mode (?), or excluded
            if grep -q "^$package!$" /sdcard/customize.txt; then
                echo "> $package force use \"!\" [GCS]"
                echo "$package!" >> "$TARGET_FILE"
                continue
    
            elif grep -q "teeBroken=false" "$TARGET_DIR/tee_status" && grep -q "^$package?$" /sdcard/customize.txt; then
                echo "> $package force use \"?\" [LHM]"
                echo "$package?" >> "$TARGET_FILE"
                continue
    
            elif grep -q "^$package$" /sdcard/customize.txt; then
                echo "> $package excluded"
                sleep 0.5
                continue
            fi
    
            # If the first line is "!", force GCS mode for all remaining packages
            if head -n 1 /sdcard/customize.txt | grep -q "^!$"; then
                echo "$package!" >> "$TARGET_FILE"
            else
                echo "$package" >> "$TARGET_FILE"  # Default Auto Mode
            fi
        else
            # If no customize.txt, use Auto Mode
            echo "$package" >> "$TARGET_FILE"
        fi
    done

    echo "> Done adding package to target.txt"
    echo "=== ENDED ==="

else
    # Error message if Tricky Store is not installed
    echo "=== ERROR ==="
    sleep 1
    echo "> Hello there👋🏻"
    sleep 0.5
    echo "> You got message from Citra 💌."
    sleep 1
    echo "> Is tricky store installed 🤔?"
    sleep 1
    echo "> Please reinstall tricky store😑."
    sleep 3.5 && exit
fi

# Check if the fp.sh file exists and execute it with root privileges
[ -f $MODPATH/fp.sh ] && cmd sh $MODPATH/fp.sh || echo -e "! ERR: 1 - internal error"

# Check if the key.sh file exists and execute it with root privileges
[ -f $MODPATH/key.sh ] && cmd sh $MODPATH/key.sh || { [ "$(cmd sh $MODPATH/key.sh; echo $?)" -eq 2 ] || echo -e "! Aborted"; }

# Remove the key file if it exists
[ -f $MODPATH/key ] && rm -rf "$MODPATH/key"

# Remove PIXEL_BETA_HTML file if it exists
[ -f $DIR/PIXEL_BETA_HTML ] && su -c "rm -rf $MODPATH/BETA"

# Remove PIXEL_GET_HTML file if it exists
[ -f $DIR/PIXEL_GET_HTML ] && su -c "rm -rf $MODPATH/GET_PIXEL"

# Remove PIXEL_GSI_HTML file if it exists
[ -f $DIR/PIXEL_GSI_HTML ] && su -c "rm -rf $MODPATH/PIXEL"