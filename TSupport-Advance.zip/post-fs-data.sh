#!/bin/sh

# Define Directory
SHAMIKO="/data/adb/modules/zygisk_shamiko"

# Delete Old Action
[ -f $SHAMIKO/action.sh ] && rm -rf $SHAMIKO/action.sh