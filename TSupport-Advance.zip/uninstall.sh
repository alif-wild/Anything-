rm -rf /data/adb/modules/zygisk_shamiko/action.sh
