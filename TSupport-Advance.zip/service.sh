#!/system/bin/sh

# Define Variable & Directory
MAGISK_VER="$(magisk -V)"
SHAMIKO="/data/adb/modules/zygisk_shamiko"
TARGET_DIR="/data/adb/tricky_store"
TARGET_FILE="$TARGET_DIR/target.txt"
TARGET_BACKUP="$TARGET_DIR/target.txt.bak"
EXCLUDE_FILE="/sdcard/exclude.txt"
AUTOLOG="$TARGET_DIR/autolog"

# Sleep for a second
sleep 20

# Condition Checker
if [ "$MAGISK_VER" -gt 27007 ]; then
    echo """#!/bin/sh
DIR=\"/data/adb/shamiko\"
    
if [ -d \$DIR ] && [ -f \$DIR/whitelist ]; then
    rm -rf \$DIR/whitelist
    sleep 0.4
    exit 0
elif [ -d \$DIR ] && [ ! -f \$DIR/whitelist ]; then
    touch \$DIR/whitelist
    sleep 0.4
    exit 0
else
    echo -e \"! ERROR : Shamiko directory not found\"
    exit 1
fi
""" > $SHAMIKO/action.sh
fi

backup_target() {
    [ -f "$TARGET_FILE" ] && [ ! -f "$TARGET_BACKUP" ] && su -c mv "$TARGET_FILE" "$TARGET_BACKUP"
}

update_autolog() {
    # Get the list of package names
    packages=$(awk '{print $1}' /data/system/packages.list)
    
    # Check if `customize.txt` file exists
    if [ -f /sdcard/customize.txt ]; then

        # Handle the `!` in the first line as default mode for Generated Certificate Support (GCS)
        use_default_gcs=false
        if head -n 1 /sdcard/customize.txt | grep -q "^!$"; then
            use_default_gcs=true
        fi

        # Loop through each package
        for package in $packages; do
            if grep -q "^$package!$" /sdcard/customize.txt; then
                # Use Generated Certificate Support (GCS) mode
                echo "$package!" >> "$AUTOLOG"

            elif grep -q "teeBroken=false" "$TARGET_DIR/tee_status" && grep -q "^$package?$" /sdcard/customize.txt; then
                # Use Leaf Hack Mode (LHM)
                echo "$package?" >> "$AUTOLOG"

            elif grep -q "^$package$" /sdcard/customize.txt; then
                # Skip package name
                continue

            elif $use_default_gcs; then
                # If the first line of customize.txt is "!", use GCS as the default mode
                echo "$package!" >> "$AUTOLOG"
            
            else
                # Default mode (Auto Mode)
                echo "$package" >> "$AUTOLOG"
            fi
        done
    else
        # If customize.txt does not exist, add all packages in Auto Mode
        for package in $packages; do
            echo "$package" >> "$AUTOLOG"
        done
    fi
    
    # Save results from AUTOLOG to TARGET_FILE and delete AUTOLOG
    [ -f "$AUTOLOG" ] && su -c cat "$AUTOLOG" > "$TARGET_FILE" && rm -f "$AUTOLOG"
}

# First Init
sleep 5
backup_target
update_autolog

# Looping Services
while true; do
    # Auto Target Service
    if [ -f /sdcard/stop-tspa-auto-target ]; then
        break
    elif [ -d "$TARGET_DIR" ]; then
        backup_target
        update_autolog
        sleep 60
    fi
done